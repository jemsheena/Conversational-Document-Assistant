# 🖥️ Local LLM Setup Guide

Run LLMs completely free on your machine! No API keys, no billing, works offline.

## Quick Start with Ollama (Recommended)

### Step 1: Install Ollama

**Windows:**
1. Download from: https://ollama.ai/download
2. Run the installer
3. Ollama will start automatically

**Mac:**
```bash
brew install ollama
```

**Linux:**
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

### Step 2: Download a Model

Open a terminal and run:

```bash
# Small, fast model (recommended for testing)
ollama pull llama3.2

# Or try other models:
# ollama pull llama3.2:3b        # Very small (2GB)
# ollama pull mistral            # Good balance
# ollama pull llama3.1:8b        # Better quality (larger)
```

### Step 3: Configure Your .env

Update `backend/.env`:

```env
# Use local LLM
LLM_PROVIDER=local

# Ollama settings (defaults shown)
LOCAL_LLM_URL=http://localhost:11434/v1
LOCAL_LLM_MODEL=llama3.2
```

### Step 4: Start Ollama

If it's not already running:
```bash
ollama serve
```

### Step 5: Restart Your Backend

Your backend will now use the local LLM!

## Alternative: LM Studio

1. Download LM Studio: https://lmstudio.ai/
2. Install and open LM Studio
3. Download a model (e.g., Llama 3.2, Mistral)
4. Start the local server (Menu → Local Server → Start Server)
5. Update `.env`:
   ```env
   LLM_PROVIDER=local
   LOCAL_LLM_URL=http://localhost:1234/v1  # LM Studio default port
   LOCAL_LLM_MODEL=your-model-name
   ```

## Model Recommendations

### Small & Fast (Good for testing):
- `phi3:mini` (2.3GB) - Very small, efficient
- `qwen2.5:0.5b` (~0.5GB) - Smallest viable option
- `tinyllama` (638MB) - Ultra-small, basic functionality
- `llama3.2:3b` (2GB) - Small but may need 4GB+ RAM
- `llama3.2` (4GB) - Fast, good quality
- `phi3` (3.8GB) - Microsoft's efficient model

### Better Quality (Slower):
- `llama3.1:8b` (4.7GB) - Better responses
- `mistral` (4.1GB) - Great balance
- `neural-chat` (7GB) - Conversation-focused

### Best Quality (Slower, requires more RAM):
- `llama3.1:70b` (40GB) - Excellent quality
- `mixtral` (26GB) - Mix of experts model

## Managing Models

### List installed models
```bash
ollama list
```

### Delete a model (to free up space)
```bash
ollama rm model-name
```

Example:
```bash
ollama rm llama3.1:8b  # Removes the 8B model (~4.9GB freed)
```

### Check disk usage
```bash
ollama list  # Shows model names and sizes
```

## Troubleshooting

### "Cannot connect to local LLM"
- Ensure Ollama is running: `ollama serve`
- Check if port 11434 is available
- Try: `curl http://localhost:11434/api/tags` to verify Ollama is running

### Model not found
- Download the model: `ollama pull model-name`
- Check available models: `ollama list`

### "Model requires more system memory"
- **Try the smallest models first:**
  ```bash
  ollama pull phi3:mini      # ~2.3GB, very efficient
  ollama pull qwen2.5:0.5b   # ~0.5GB, smallest option
  ollama pull tinyllama      # 638MB, ultra-small
  ```
- Delete larger models: `ollama rm llama3.1:8b` or `ollama rm llama3.2:3b`
- Close other applications to free up RAM (browsers, IDEs, etc.)
- Check available RAM: Task Manager (Windows) → Performance tab
- If still fails, you may need at least 4GB free RAM for the smallest models

### Slow responses
- Use a smaller model (llama3.2:3b instead of llama3.1:8b)
- Close other applications to free up RAM
- Consider using a GPU if available

## Advantages of Local LLMs

✅ **Completely Free** - No API costs
✅ **Private** - Data never leaves your machine
✅ **Offline** - Works without internet
✅ **Fast** - No network latency
✅ **No Rate Limits** - Generate as much as you want

## Performance Tips

1. **Use GPU if available** - Ollama automatically uses GPU if detected
2. **Close other apps** - Free up RAM for the model
3. **Start with smaller models** - Test with 3B models first
4. **Monitor RAM usage** - Models need RAM to run

## Next Steps

Once set up, your Document Assistant will use the local LLM for all chat responses. No API keys needed!

