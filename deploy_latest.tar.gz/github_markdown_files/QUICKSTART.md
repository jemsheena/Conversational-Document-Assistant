# 🚀 Quick Start Guide

## Prerequisites
- Python 3.8+ (with venv)
- Node.js 16+ and npm
- (Optional) OpenAI API key for chat functionality

## Step 1: Backend Setup

### 1.1 Navigate to backend directory
```powershell
cd C:\Users\USER\Conversational-Document-Assistant\backend
```

### 1.2 Activate virtual environment
```powershell
.\venv\Scripts\Activate.ps1
```

If you get an execution policy error, run this first:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### 1.3 (First time only) Install dependencies
```powershell
pip install -r requirements.txt
python init_db.py
```

### 1.4 Set LLM Provider (Choose One)

**Option A: Local LLM (FREE - Recommended for Students!)**

1. Install Ollama: https://ollama.ai/download
2. Download a model: `ollama pull llama3.2`
3. Create `.env` file:
```env
LLM_PROVIDER=local
LOCAL_LLM_URL=http://localhost:11434/v1
LOCAL_LLM_MODEL=llama3.2
```

See `LOCAL_LLM_SETUP.md` for detailed instructions.

**Option B: Use OpenAI (Paid but Reliable)**

Create a `.env` file:
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=your-api-key-here
```

Get your API key from: https://platform.openai.com/api-keys

**Or set it in PowerShell:**
```powershell
$env:LLM_PROVIDER="openai"
$env:OPENAI_API_KEY="your-api-key-here"
```

### 1.5 Start the backend server
```powershell
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Or use the venv Python directly:**
```powershell
.\venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The backend will be available at: `http://localhost:8000`
- API Docs: http://localhost:8000/docs
- Health Check: http://localhost:8000/health

---

## Step 2: Frontend Setup

### 2.1 Open a NEW terminal/PowerShell window

### 2.2 Navigate to frontend directory
```powershell
cd C:\Users\USER\Conversational-Document-Assistant\frontend
```

### 2.3 (First time only) Install dependencies
```powershell
npm install
```

### 2.4 Start the frontend dev server
```powershell
npm run dev
```

The frontend will be available at: `http://localhost:5173`

---

## Step 3: Using the Application

1. **Open your browser** and go to: `http://localhost:5173`

2. **Login** (MVP mode - any email/password works):
   - Email: `user@example.com`
   - Password: `password`

3. **Create a Collection**:
   - Click "Collections" in the sidebar
   - Click "New Collection"
   - Enter a name and click "Create"

4. **Upload PDFs**:
   - Click "Uploads" in the sidebar
   - Select your collection
   - Drag and drop PDF files or click to browse
   - Click "Upload & Index"

5. **Start Chatting**:
   - Click "Chat" in the sidebar
   - Make sure a collection is selected
   - Ask questions about your uploaded documents!

---

## Troubleshooting

### Backend won't start - "ModuleNotFoundError"
**Solution**: Make sure you're using the venv Python:
```powershell
.\venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

### Frontend shows TypeScript errors
**Solution**: All TypeScript has been removed. If you see errors, try:
```powershell
cd frontend
npm install
npm run dev
```

### Backend says "OPENAI_API_KEY not set"
**Solution A (FREE)**: Use Hugging Face instead! Add to `backend/.env`:
```env
LLM_PROVIDER=huggingface
```
No API key needed! (Get a free token from https://huggingface.co/settings/tokens for faster responses)

**Solution B**: Use OpenAI (paid). Set in `backend/.env`:
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=your-key-here
```

### Port already in use
**Solution**: Kill the process using the port:
```powershell
# For port 8000 (backend)
netstat -ano | findstr :8000
taskkill /PID <PID_NUMBER> /F

# For port 5173 (frontend)
netstat -ano | findstr :5173
taskkill /PID <PID_NUMBER> /F
```

---

## What's Running Where

- **Backend**: `http://localhost:8000` (FastAPI)
- **Frontend**: `http://localhost:5173` (Vite + React)
- **Database**: `backend/rag.db` (SQLite)
- **PDF Storage**: `backend/data/pdfs/`
- **Vector Indices**: `backend/data/indices/`

---

## API Endpoints

- `GET /health` - Health check
- `POST /auth/login` - Login
- `GET /collections` - List collections
- `POST /collections` - Create collection
- `POST /ingest` - Upload PDFs
- `POST /chat` - Chat with documents (SSE streaming)
- `GET /search` - Semantic search
- `GET /docs` - List documents
- `GET /metrics` - System metrics

Full API docs: http://localhost:8000/docs


