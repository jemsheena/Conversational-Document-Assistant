# 🚀 Quick Deployment Guide

## Prerequisites Checklist

- [ ] AWS CLI installed (`aws --version`)
- [ ] AWS credentials configured (`aws configure`)
- [ ] Docker installed and running
- [ ] OpenAI API key (or other LLM provider)

## 🆓 Fastest Path: EC2 Free Tier (Recommended for Getting Started)

**Best option if you want FREE deployment!** EC2 free tier gives you 750 hours/month for 12 months.

### Quick EC2 Deployment

1. **Launch EC2 Instance:**
   - Go to AWS Console → EC2 → Launch Instance
   - Choose: **Amazon Linux 2023**, **t2.micro** (FREE TIER)
   - Security Group: Allow HTTP (80), SSH (22)
   - Launch and download key pair

2. **Connect and Deploy:**
   ```bash
   # Connect (Windows PowerShell)
   ssh -i your-key.pem ec2-user@<instance-ip>
   
   # Install Docker
   sudo yum update -y
   sudo yum install docker git -y
   sudo systemctl start docker
   sudo systemctl enable docker
   sudo usermod -a -G docker ec2-user
   
   # Install Docker Compose
   sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
   sudo chmod +x /usr/local/bin/docker-compose
   
   # Clone and deploy
   git clone https://github.com/your-repo/Conversational-Document-Assistant.git
   cd Conversational-Document-Assistant
   
   # Create .env
   cd backend
   echo "LLM_PROVIDER=openai" > .env
   echo "OPENAI_API_KEY=your-key" >> .env
   echo "CORS_ORIGINS=http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):80" >> .env
   cd ..
   
   # Start
   docker-compose up -d
   ```

3. **Access:** `http://<your-instance-ip>`

See [AWS_DEPLOYMENT.md](AWS_DEPLOYMENT.md) Option 1 for detailed steps.

---

## Alternative: ECS Fargate (Production)

### 1. Build and Push Images

**Linux/Mac:**
```bash
chmod +x deploy-aws.sh
./deploy-aws.sh
```

**Windows:**
```powershell
.\deploy-aws.ps1
```

### 2. Create Task Definition

1. Go to AWS Console → ECS → Task Definitions
2. Click "Create new Task Definition"
3. Use the template from `ecs-task-definition.json`
4. Replace placeholders:
   - `<ACCOUNT_ID>` → Your AWS Account ID
   - `<REGION>` → Your AWS region (e.g., us-east-1)
   - Update secrets ARNs

### 3. Create ECS Service

1. Go to ECS → Clusters → rag-cluster
2. Click "Create Service"
3. Configure:
   - **Task Definition**: rag-backend
   - **Service Name**: rag-backend-service
   - **Desired Count**: 1
   - **Launch Type**: Fargate
   - **VPC**: Your VPC
   - **Subnets**: Public subnets
   - **Security Group**: Allow port 8000
   - **Load Balancer**: Create new or use existing

### 4. Deploy Frontend to S3

```bash
cd frontend
export VITE_API_BASE=https://your-alb-url.us-east-1.elb.amazonaws.com
npm run build
aws s3 sync dist/ s3://your-bucket-name --delete
```

### 5. Update CORS

In your backend task definition, update:
```
CORS_ORIGINS=https://your-s3-website-url.s3-website-us-east-1.amazonaws.com
```

## Alternative: Elastic Beanstalk (Easier but less flexible)

```bash
cd backend
pip install awsebcli
eb init
eb create rag-backend-env
eb deploy
```

## Testing Locally with Docker

```bash
docker-compose up -d
```

Backend: http://localhost:8000
Frontend: http://localhost:80

## Common Issues

**"No space left on device"**
→ Increase EBS volume size or clean up Docker images

**"Task failed to start"**
→ Check CloudWatch Logs for errors

**"Connection refused"**
→ Verify security groups allow traffic on port 8000

**"CORS error"**
→ Update CORS_ORIGINS to include your frontend URL

## Next Steps

- [ ] Set up custom domain
- [ ] Configure SSL certificate
- [ ] Set up auto-scaling
- [ ] Configure monitoring alerts
- [ ] Set up CI/CD pipeline

For detailed instructions, see [AWS_DEPLOYMENT.md](AWS_DEPLOYMENT.md)

