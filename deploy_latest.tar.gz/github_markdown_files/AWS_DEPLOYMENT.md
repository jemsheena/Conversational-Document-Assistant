# 🚀 AWS Deployment Guide

This guide will help you deploy the Conversational Document Assistant on AWS using multiple deployment options.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Deployment Options](#deployment-options)
3. [Option 1: AWS Elastic Beanstalk (Easiest)](#option-1-aws-elastic-beanstalk-easiest)
4. [Option 2: AWS ECS with Fargate (Recommended)](#option-2-aws-ecs-with-fargate-recommended)
5. [Option 3: EC2 Instance](#option-3-ec2-instance)
6. [Frontend Deployment (S3 + CloudFront)](#frontend-deployment-s3--cloudfront)
7. [Post-Deployment Configuration](#post-deployment-configuration)

## Prerequisites

Before starting, ensure you have:

- ✅ AWS Account with appropriate permissions
- ✅ AWS CLI installed and configured (`aws configure`)
- ✅ Docker installed locally (for building images)
- ✅ ECR access (for pushing Docker images)
- ✅ Domain name (optional, for custom domain)

## Deployment Options

### Quick Comparison

| Option | Difficulty | Cost | Scalability | Best For |
|--------|-----------|------|-------------|----------|
| **EC2 (Free Tier)** | ⭐⭐ Medium | **FREE** ⭐ | Low-Medium | **Best for getting started!** |
| Elastic Beanstalk | ⭐ Easy | $$ | Medium | Quick deployment, managed service |
| ECS Fargate | ⭐⭐ Medium | $$$ | High | Production, auto-scaling |
| EC2 (Paid) | ⭐⭐⭐ Hard | $ | Low | Full control, custom setup |

### 🆓 AWS Free Tier (12 Months)

**EC2 Free Tier includes:**
- ✅ **750 hours/month** of t2.micro or t3.micro instances
- ✅ **30 GB** of EBS storage
- ✅ **5 GB** of S3 storage
- ✅ **15 GB** of data transfer out

**Perfect for this application!** You can run the entire stack for free for 12 months.

**Note:** After 12 months, t3.micro costs ~$7-10/month (still very affordable)

---

## Option 1: EC2 Instance (FREE TIER - Recommended for Getting Started) 🆓

**Best choice if you want to deploy for FREE!** The EC2 free tier gives you everything you need for 12 months.

### Step 1: Launch EC2 Instance (Free Tier Eligible)

1. Go to **EC2 Console** → **Launch Instance**
2. Configure:
   - **Name**: `rag-assistant`
   - **AMI**: **Amazon Linux 2023** (free tier eligible) or Ubuntu 22.04
   - **Instance Type**: **t2.micro** or **t3.micro** (FREE TIER) ⭐
     - ⚠️ **Important**: Make sure to select a free tier eligible instance!
   - **Key Pair**: Create new or select existing (download the .pem file!)
   - **Network Settings**: 
     - Allow **HTTP (80)** traffic from anywhere (0.0.0.0/0)
     - Allow **HTTPS (443)** traffic from anywhere (optional)
     - Allow **SSH (22)** from your IP only (for security)
   - **Storage**: 20 GB gp3 (free tier includes 30 GB)
   - **Advanced**: Enable "Free tier only" filter

3. Click **Launch Instance**

### Step 2: Connect to Your Instance

**Windows (PowerShell):**
```powershell
# Navigate to where your .pem file is
cd C:\path\to\your\key

# Set permissions (if needed)
icacls.exe your-key.pem /inheritance:r
icacls.exe your-key.pem /grant:r "%username%:R"

# Connect
ssh -i your-key.pem ec2-user@<your-instance-public-ip>
```

**Linux/Mac:**
```bash
chmod 400 your-key.pem
ssh -i your-key.pem ec2-user@<your-instance-public-ip>
```

### Step 3: Install Dependencies

```bash
# Update system
sudo yum update -y  # Amazon Linux
# OR
sudo apt update && sudo apt upgrade -y  # Ubuntu

# Install Docker
sudo yum install docker -y  # Amazon Linux
# OR
sudo apt install docker.io -y  # Ubuntu

# Start Docker
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker ec2-user

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install Git (if not already installed)
sudo yum install git -y  # Amazon Linux
# OR
sudo apt install git -y  # Ubuntu

# Logout and login again for group changes
exit
# Then SSH back in
```

### Step 4: Deploy Application

```bash
# Clone your repository
git clone https://github.com/your-username/Conversational-Document-Assistant.git
cd Conversational-Document-Assistant

# Create .env file for backend
cd backend
cat > .env << EOF
LLM_PROVIDER=openai
OPENAI_API_KEY=your-api-key-here
CORS_ORIGINS=http://<your-instance-ip>:80,http://<your-instance-ip>
JWT_SECRET=$(openssl rand -hex 32)
DATABASE_URL=sqlite:///./rag.db
DATA_DIR=./data
EOF

# Get your instance IP (you'll need this)
curl http://169.254.169.254/latest/meta-data/public-ipv4

# Update CORS_ORIGINS with the actual IP
nano .env  # Edit CORS_ORIGINS with your IP

# Go back to root
cd ..

# Start with Docker Compose
docker-compose up -d

# Check if containers are running
docker ps
```

### Step 5: Set Up Nginx Reverse Proxy (Recommended)

```bash
# Install Nginx
sudo yum install nginx -y  # Amazon Linux
# OR
sudo apt install nginx -y  # Ubuntu

# Create Nginx config
sudo nano /etc/nginx/conf.d/rag.conf
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name _;

    # Frontend
    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # For SSE streaming
        proxy_buffering off;
        proxy_cache off;
        proxy_set_header Connection '';
        proxy_http_version 1.1;
        chunked_transfer_encoding off;
    }
}
```

```bash
# Test Nginx config
sudo nginx -t

# Start Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Restart if needed
sudo systemctl restart nginx
```

### Step 6: Access Your Application

1. Get your instance public IP from EC2 Console
2. Open browser: `http://<your-instance-ip>`
3. You should see the frontend!

### Step 7: Set Up Auto-Start (Optional)

Create a systemd service to auto-start on reboot:

```bash
sudo nano /etc/systemd/system/rag-assistant.service
```

Add:
```ini
[Unit]
Description=RAG Assistant Docker Compose
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/ec2-user/Conversational-Document-Assistant
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
User=ec2-user

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable rag-assistant.service
sudo systemctl start rag-assistant.service
```

### Free Tier Tips

✅ **Stay within free tier:**
- Use t2.micro or t3.micro only
- Keep storage under 30 GB
- Monitor usage in AWS Billing Dashboard

⚠️ **Watch out for:**
- Data transfer out (first 15 GB free)
- EBS snapshots (not included in free tier)
- Elastic IP (free only if attached to running instance)

💰 **After 12 months:** t3.micro costs ~$7-10/month (still very affordable!)

---

## Option 2: AWS Elastic Beanstalk (Easiest)

### Step 1: Install EB CLI

```bash
pip install awsebcli
```

### Step 2: Initialize Elastic Beanstalk

```bash
cd backend
eb init -p docker -r us-east-1 rag-assistant-backend
```

### Step 3: Create Application Version

```bash
# Build Docker image
docker build -t rag-backend:latest .

# Tag for ECR (replace with your account ID)
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# Create ECR repository
aws ecr create-repository --repository-name rag-backend --region us-east-1

# Tag and push
docker tag rag-backend:latest <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-backend:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-backend:latest
```

### Step 4: Create Environment

```bash
eb create rag-backend-env \
  --instance-type t3.medium \
  --envvars LLM_PROVIDER=openai,OPENAI_API_KEY=your-key-here,CORS_ORIGINS=https://your-frontend-domain.com
```

### Step 5: Deploy

```bash
eb deploy
```

---

## Option 3: AWS ECS with Fargate (Production)

### Step 1: Create ECR Repositories

```bash
# Backend repository
aws ecr create-repository --repository-name rag-backend --region us-east-1

# Frontend repository (optional, if using container)
aws ecr create-repository --repository-name rag-frontend --region us-east-1
```

### Step 2: Build and Push Docker Images

```bash
# Login to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# Build backend
cd backend
docker build -t rag-backend:latest .
docker tag rag-backend:latest <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-backend:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-backend:latest

# Build frontend
cd ../frontend
docker build --build-arg VITE_API_BASE=https://api.yourdomain.com -t rag-frontend:latest .
docker tag rag-frontend:latest <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-frontend:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-frontend:latest
```

### Step 3: Create Task Definitions

Use the provided `ecs-task-definition.json` or create via AWS Console:

1. Go to ECS → Task Definitions → Create new
2. Configure:
   - **Family**: rag-backend
   - **Container**: rag-backend
   - **Image**: `<ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/rag-backend:latest`
   - **Port**: 8000
   - **Environment Variables**:
     - `LLM_PROVIDER=openai`
     - `OPENAI_API_KEY` (from Secrets Manager)
     - `CORS_ORIGINS=https://your-frontend-domain.com`
     - `DATABASE_URL=sqlite:///./rag.db`
   - **Memory**: 2048 MB
   - **CPU**: 1024 (1 vCPU)

### Step 4: Create ECS Cluster

```bash
aws ecs create-cluster --cluster-name rag-cluster --region us-east-1
```

### Step 5: Create Application Load Balancer

```bash
# Create security group
aws ec2 create-security-group \
  --group-name rag-alb-sg \
  --description "Security group for RAG ALB" \
  --region us-east-1

# Allow HTTP/HTTPS (replace with your VPC subnet IDs)
aws ec2 authorize-security-group-ingress \
  --group-id <ALB_SG_ID> \
  --protocol tcp \
  --port 80 \
  --cidr 0.0.0.0/0 \
  --region us-east-1

# Create ALB (use AWS Console for easier setup)
```

### Step 6: Create ECS Service

```bash
aws ecs create-service \
  --cluster rag-cluster \
  --service-name rag-backend-service \
  --task-definition rag-backend:1 \
  --desired-count 1 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:us-east-1:xxx:targetgroup/xxx,containerName=rag-backend,containerPort=8000"
```

---

## Option 4: EC2 Instance (Paid - Larger Instances)

For larger instances (t3.medium, t3.large, etc.) when you need more resources, follow the same steps as Option 1, but select a larger instance type. This is useful when:
- Running larger local LLM models
- Handling more concurrent users
- Processing larger documents

**Note:** These instances are NOT free tier eligible and will incur charges (~$30-100/month depending on size).

---

## Frontend Deployment (S3 + CloudFront)

### Step 1: Build Frontend

```bash
cd frontend

# Set API base URL
export VITE_API_BASE=https://api.yourdomain.com

# Build
npm run build
```

### Step 2: Create S3 Bucket

```bash
aws s3 mb s3://rag-frontend-bucket --region us-east-1

# Enable static website hosting
aws s3 website s3://rag-frontend-bucket \
  --index-document index.html \
  --error-document index.html
```

### Step 3: Upload Build Files

```bash
aws s3 sync dist/ s3://rag-frontend-bucket --delete

# Set proper permissions
aws s3 cp dist/index.html s3://rag-frontend-bucket/index.html \
  --content-type "text/html" \
  --cache-control "no-cache"
```

### Step 4: Create CloudFront Distribution (Optional but Recommended)

1. Go to CloudFront Console → Create Distribution
2. Configure:
   - **Origin Domain**: rag-frontend-bucket.s3.amazonaws.com
   - **Viewer Protocol Policy**: Redirect HTTP to HTTPS
   - **Default Root Object**: index.html
   - **Error Pages**: 404 → /index.html (for SPA routing)

### Step 5: Update CORS in Backend

Update backend CORS_ORIGINS to include your CloudFront domain:
```
CORS_ORIGINS=https://d1234567890.cloudfront.net,https://yourdomain.com
```

---

## Post-Deployment Configuration

### 1. Set Up Environment Variables

For ECS/EB, use AWS Systems Manager Parameter Store or Secrets Manager:

```bash
# Store secrets
aws secretsmanager create-secret \
  --name rag/openai-api-key \
  --secret-string "your-api-key-here" \
  --region us-east-1

# Reference in task definition
{
  "secrets": [
    {
      "name": "OPENAI_API_KEY",
      "valueFrom": "arn:aws:secretsmanager:us-east-1:xxx:secret:rag/openai-api-key"
    }
  ]
}
```

### 2. Set Up Database (Optional - Migrate from SQLite)

For production, consider migrating to RDS PostgreSQL:

```bash
# Create RDS instance
aws rds create-db-instance \
  --db-instance-identifier rag-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --master-username admin \
  --master-user-password YourPassword123 \
  --allocated-storage 20
```

### 3. Set Up S3 for File Storage

```bash
# Create S3 bucket for PDFs and indices
aws s3 mb s3://rag-storage-bucket --region us-east-1

# Update backend to use S3 (modify config.py)
```

### 4. Set Up Monitoring

- **CloudWatch Logs**: Automatic for ECS/EB
- **CloudWatch Metrics**: Monitor CPU, memory, request count
- **Alarms**: Set up for high error rates, low memory

### 5. Set Up Auto-Scaling

For ECS:
```bash
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --scalable-dimension ecs:service:DesiredCount \
  --resource-id service/rag-cluster/rag-backend-service \
  --min-capacity 1 \
  --max-capacity 10
```

---

## Quick Deployment Script

Use the provided `deploy-aws.sh` script for automated deployment:

```bash
chmod +x deploy-aws.sh
./deploy-aws.sh
```

---

## Troubleshooting

### Backend not starting
- Check CloudWatch Logs
- Verify environment variables
- Check security group rules

### Frontend can't connect to backend
- Verify CORS_ORIGINS includes frontend URL
- Check ALB/security group allows traffic
- Verify API base URL in frontend build

### High memory usage
- Consider using larger instance types
- Enable model caching
- Use smaller embedding models

---

## Cost Optimization Tips

1. **Use Spot Instances** for non-production
2. **Reserved Instances** for predictable workloads
3. **S3 Lifecycle Policies** for old data
4. **CloudFront Caching** to reduce backend load
5. **Auto-scaling** to scale down during low usage

---

## Security Checklist

- [ ] Use HTTPS (CloudFront/ALB)
- [ ] Store secrets in Secrets Manager
- [ ] Enable VPC for ECS tasks
- [ ] Use IAM roles (not access keys)
- [ ] Enable CloudTrail logging
- [ ] Set up WAF rules
- [ ] Regular security updates
- [ ] Enable MFA for AWS account

---

## Next Steps

1. Set up CI/CD pipeline (GitHub Actions, CodePipeline)
2. Implement database migrations
3. Add monitoring and alerting
4. Set up backup strategies
5. Configure custom domain with SSL

---

**Need Help?** Check AWS documentation or open an issue on GitHub.

