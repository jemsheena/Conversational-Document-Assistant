# Fix Disk Space on EC2

## Step 1: Check Disk Space

```bash
# Check disk usage
df -h

# Check what's using space
du -sh ~/* | sort -hr | head -10
```

## Step 2: Clean Up Docker

```bash
# Remove unused Docker images
docker system prune -a -f

# Remove all stopped containers
docker container prune -f

# Remove unused volumes
docker volume prune -f

# Check Docker disk usage
docker system df
```

## Step 3: Clean Up System

```bash
# Clean package cache
sudo yum clean all

# Remove old logs
sudo journalctl --vacuum-time=1d

# Check what's using space
sudo du -sh /var/* | sort -hr | head -10
```

## Step 4: Check EBS Volume Size

```bash
# Check current disk size
lsblk

# If you need more space, you'll need to resize the EBS volume in AWS Console
```

## Step 5: Alternative - Build Locally and Push

If disk space is still an issue, build images locally and push to a registry, or use a different deployment method.


