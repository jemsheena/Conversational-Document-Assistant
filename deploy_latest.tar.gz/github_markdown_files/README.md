# 📚 Conversational Document Assistant

> A production-ready RAG-powered PDF chat system with streaming responses, citations, and multi-LLM support

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-18+-61dafb.svg)](https://reactjs.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

An intelligent document assistant that allows you to chat with your PDFs using Retrieval-Augmented Generation (RAG). Get accurate, cited answers from your documents with support for multiple LLM providers including OpenAI, local models (Ollama), and Hugging Face.

## ✨ Features

### Core Capabilities
- 📄 **PDF Processing**: Automatic parsing, chunking, and embedding of PDF documents
- 🔍 **Semantic Search**: Vector-based retrieval with FAISS for fast similarity search
- 🎯 **Intelligent Reranking**: Cross-encoder reranking for improved relevance
- 💬 **Streaming Chat**: Real-time streaming responses with Server-Sent Events (SSE)
- 📑 **Source Citations**: Inline citations with clickable source references
- 📊 **Collections Management**: Organize documents into collections for better organization

### LLM Provider Support
- 🤖 **OpenAI**: GPT-4, GPT-4o-mini, and other OpenAI models
- 🖥️ **Local LLMs**: Ollama, LM Studio (completely free, runs offline)
- 🤗 **Hugging Face**: Free inference API (when available)

### User Experience
- 🎨 **Modern UI**: Clean, responsive interface built with React and Tailwind CSS
- 📱 **Responsive Design**: Works on desktop and mobile devices
- ⚡ **Fast Retrieval**: Optimized vector search with caching
- 🔒 **Authentication**: JWT-based authentication system
- 📈 **Metrics**: System metrics and performance monitoring

## 🏗️ Architecture

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│   Frontend  │────────▶│   Backend    │────────▶│  Vector DB  │
│   (React)   │  REST   │  (FastAPI)   │  FAISS  │   (FAISS)   │
└─────────────┘         └──────────────┘         └─────────────┘
                              │
                              ▼
                        ┌──────────────┐
                        │  LLM Provider │
                        │ (OpenAI/Local)│
                        └──────────────┘
```

### Technology Stack

**Frontend:**
- React 18+ with Vite
- Tailwind CSS for styling
- React Context for state management
- Server-Sent Events for streaming

**Backend:**
- FastAPI (Python 3.8+)
- SQLite for metadata storage
- FAISS for vector similarity search
- Sentence-Transformers for embeddings
- Cross-encoder for reranking

**RAG Pipeline:**
1. **Ingestion**: PDF parsing → Text chunking → Embedding generation
2. **Storage**: FAISS vector index + SQLite metadata
3. **Retrieval**: Similarity search → Reranking → Diversification
4. **Generation**: Context building → LLM inference → Citation validation

## 🚀 Quick Start

### Prerequisites

- **Python 3.8+** with `venv` support
- **Node.js 16+** and `npm`
- **8GB+ RAM** (for local LLMs, 4GB+ for OpenAI)
- **LLM Provider**: Choose one:
  - OpenAI API key, OR
  - Ollama (for local LLMs), OR
  - Hugging Face API (limited availability)

### Installation

#### 1. Clone the Repository

```bash
git clone https://github.com/jemsheena/Conversational-Document-Assistant.git
cd Conversational-Document-Assistant
```

#### 2. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
.\venv\Scripts\Activate.ps1
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Initialize database
python init_db.py
```

#### 3. Configure LLM Provider

Create a `.env` file in the `backend` directory:

**Option A: Local LLM (FREE - Recommended)**
```env
LLM_PROVIDER=local
LOCAL_LLM_URL=http://localhost:11434/v1
LOCAL_LLM_MODEL=qwen2.5:0.5b
```

See [LOCAL_LLM_SETUP.md](LOCAL_LLM_SETUP.md) for detailed Ollama setup instructions.

**Option B: OpenAI (Paid)**
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=your-api-key-here
DEFAULT_LLM_MODEL=gpt-4o-mini
```

**Option C: Hugging Face (Limited)**
```env
LLM_PROVIDER=huggingface
HUGGINGFACE_API_KEY=your-hf-token-here
HUGGINGFACE_MODEL=gpt2
```

#### 4. Start Backend Server

```bash
# Using uvicorn directly
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Or using Python module
python -m uvicorn app.main:app --reload
```

Backend will be available at `http://localhost:8000`

#### 5. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will be available at `http://localhost:5173`

## 📖 Usage

### 1. Access the Application

Open your browser and navigate to `http://localhost:5173`

### 2. Login

For MVP, any email/password combination works:
- Email: `user@example.com`
- Password: `password`

### 3. Create a Collection

1. Click **"Collections"** in the sidebar
2. Click **"New Collection"**
3. Enter a name and click **"Create"**

### 4. Upload PDFs

1. Click **"Uploads"** in the sidebar
2. Select your collection
3. Drag and drop PDF files or click to browse
4. Click **"Upload & Index"**
5. Wait for processing to complete

### 5. Start Chatting

1. Click **"Chat"** in the sidebar
2. Select your collection
3. Ask questions about your uploaded documents
4. View source citations by clicking "View sources"

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the `backend` directory:

```env
# LLM Provider (openai, local, huggingface)
LLM_PROVIDER=local

# Local LLM (Ollama)
LOCAL_LLM_URL=http://localhost:11434/v1
LOCAL_LLM_MODEL=qwen2.5:0.5b

# OpenAI (if using OpenAI)
OPENAI_API_KEY=your-key-here
DEFAULT_LLM_MODEL=gpt-4o-mini

# Hugging Face (if using HF)
HUGGINGFACE_API_KEY=your-token-here
HUGGINGFACE_MODEL=gpt2

# Embeddings
EMBED_MODEL=sentence-transformers/all-MiniLM-L6-v2

# RAG Parameters
DEFAULT_K=12                    # Number of passages to retrieve
DEFAULT_RERANK_K=6              # Number of passages after reranking
DEFAULT_CHUNK_SIZE=900          # Characters per chunk
DEFAULT_CHUNK_OVERLAP=120       # Overlap between chunks
MIN_RETRIEVAL_SCORE=0.1         # Minimum relevance score

# Database
DATABASE_URL=sqlite:///rag.db

# Storage Paths
DATA_DIR=./data
PDF_STORAGE_DIR=./data/pdfs
INDEX_DIR=./data/indices
```

See `backend/app/config.py` for all available configuration options.

## 📚 API Documentation

### Authentication

```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password"
}
```

### Collections

```http
GET /collections
Authorization: Bearer <token>

POST /collections
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "My Collection"
}
```

### Document Ingestion

```http
POST /ingest
Authorization: Bearer <token>
Content-Type: multipart/form-data

collection: "collection-id"
files: [file1.pdf, file2.pdf]
chunk_size: 900
overlap: 120
```

### Chat

```http
POST /chat
Authorization: Bearer <token>
Content-Type: application/json

{
  "query": "What is the main topic?",
  "collection": "collection-id",
  "k": 12,
  "rerank_k": 6,
  "model": "gpt-4o-mini",
  "max_tokens": 600
}
```

**Response:** Server-Sent Events (SSE) stream

### Semantic Search

```http
GET /search?q=query&collection=collection-id&k=10
Authorization: Bearer <token>
```

### Interactive API Docs

Once the backend is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🧪 Testing

1. Start backend: `uvicorn app.main:app --reload`
2. Start frontend: `npm run dev`
3. Login with any credentials
4. Create a collection
5. Upload a test PDF
6. Ask questions in the chat interface

## 📁 Project Structure

```
Conversational-Document-Assistant/
├── backend/
│   ├── app/
│   │   ├── routes/          # API endpoints
│   │   ├── dto/             # Data transfer objects
│   │   ├── config.py        # Configuration
│   │   └── main.py          # FastAPI application
│   ├── rag/
│   │   ├── pdf.py           # PDF parsing
│   │   ├── chunk.py         # Text chunking
│   │   ├── embed.py         # Embedding generation
│   │   ├── store.py         # FAISS vector store
│   │   ├── rerank.py        # Cross-encoder reranking
│   │   ├── generate.py      # LLM generation (multi-provider)
│   │   └── prompt.py        # Prompt engineering
│   ├── data/                # Data storage
│   │   ├── pdfs/            # Uploaded PDFs
│   │   └── indices/         # FAISS indices
│   ├── requirements.txt     # Python dependencies
│   └── init_db.py           # Database initialization
├── frontend/
│   ├── src/
│   │   ├── pages/           # Page components
│   │   ├── components/      # Reusable components
│   │   ├── store/           # State management
│   │   └── api/             # API client
│   ├── package.json         # Node dependencies
│   └── vite.config.js       # Vite configuration
├── README.md                # This file
├── QUICKSTART.md            # Quick start guide
└── LOCAL_LLM_SETUP.md       # Local LLM setup guide
```

## 🔒 Security

- JWT-based authentication
- Password hashing (bcrypt)
- SQL injection protection (SQLAlchemy ORM)
- CORS configuration
- Environment variable protection

**Note:** MVP uses simplified authentication. For production, implement proper user management and password validation.


## ☁️ AWS Deployment

Ready to deploy to production? **Deploy for FREE with AWS Free Tier!** 🆓

### 🆓 Free Tier Option (Recommended for Getting Started)

**EC2 Free Tier** gives you:
- ✅ **750 hours/month** for 12 months (enough for 24/7 operation!)
- ✅ **30 GB storage**
- ✅ **Perfect for this application!**

### Quick Start

1. **Fastest Path - EC2 Free Tier**: See [DEPLOYMENT_QUICKSTART.md](DEPLOYMENT_QUICKSTART.md)
   - Launch t2.micro instance (FREE)
   - Deploy with Docker Compose
   - Access your app in minutes!

2. **Automated Scripts**: Use our deployment scripts
   ```bash
   # Linux/Mac
   ./deploy-aws.sh
   
   # Windows
   .\deploy-aws.ps1
   ```

3. **Full Documentation**: Check [AWS_DEPLOYMENT.md](AWS_DEPLOYMENT.md) for all options

### Deployment Options

- **EC2 Free Tier** 🆓 (Recommended): FREE for 12 months, perfect for getting started
- **ECS Fargate**: Containerized deployment with auto-scaling (paid)
- **Elastic Beanstalk**: Managed service for quick deployment (paid)
- **EC2 Paid**: Full control with larger instances (paid)
- **Frontend**: S3 + CloudFront for static hosting (5 GB free tier)

### Docker Support

Test locally with Docker:
```bash
docker-compose up -d
```

## 🚧 Roadmap

- [x] AWS deployment guide and scripts
- [ ] Production-ready authentication with user management
- [ ] PostgreSQL migration for scalability
- [ ] S3/storage integration for cloud deployment
- [ ] Multi-tenant RBAC (Role-Based Access Control)
- [ ] Evaluation suite (Ragas framework)
- [ ] Vision-RAG for scanned PDFs and images
- [ ] Query rewriting and fusion retrieval
- [ ] Advanced caching strategies
- [ ] WebSocket support for real-time updates
- [ ] Export chat history and reports

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [FastAPI](https://fastapi.tiangolo.com/) for the excellent Python web framework
- [React](https://reactjs.org/) for the frontend framework
- [Ollama](https://ollama.ai/) for local LLM support
- [FAISS](https://github.com/facebookresearch/faiss) for efficient vector search
- [Sentence-Transformers](https://www.sbert.net/) for embeddings

## 📞 Support

For issues, questions, or contributions, please open an issue on GitHub.

---

**Built with ❤️ for students and developers who want to chat with their documents**
