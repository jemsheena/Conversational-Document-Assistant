# Fix Permissions on EC2

Run these commands **on your EC2 instance** (in your SSH session):

```bash
# Fix ownership of uploaded files
sudo chown -R ec2-user:ec2-user ~/Conversational-Document-Assistant

# Remove .git directory (we don't need it)
rm -rf ~/Conversational-Document-Assistant/.git

# Verify files are there
cd ~/Conversational-Document-Assistant
ls -la
```

Then continue with deployment!


