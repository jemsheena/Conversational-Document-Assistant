# 🚀 EC2 Deployment Checklist

Use this checklist to track your progress. You've already completed the first two steps! ✅

## ✅ Completed Steps

- [x] Launch EC2 instance (t2.micro or t3.micro)
- [x] Connect via SSH

## 📋 Next Steps

### Step 3: Install Dependencies

Run these commands in your SSH terminal:

```bash
# First, check which OS you're using
cat /etc/os-release

# If Amazon Linux, run:
sudo yum update -y
sudo yum install docker git -y
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker ec2-user

# If Ubuntu, run:
sudo apt update && sudo apt upgrade -y
sudo apt install docker.io git -y
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker $USER

# Install Docker Compose (works for both)
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installations
docker --version
docker-compose --version
git --version

# IMPORTANT: Logout and login again for Docker group to take effect
exit
```

**Then SSH back in:**
```bash
ssh -i your-key.pem ec2-user@<your-instance-ip>
```

### Step 4: Get Your Instance IP

```bash
# Get your public IP (you'll need this for CORS)
curl http://169.254.169.254/latest/meta-data/public-ipv4
```

**Save this IP address!** You'll need it in the next step.

### Step 5: Clone and Deploy

```bash
# Clone your repository
# Option A: If you have it on GitHub
git clone https://github.com/your-username/Conversational-Document-Assistant.git

# Option B: If you need to upload files, use SCP from your local machine:
# scp -i your-key.pem -r /path/to/Conversational-Document-Assistant ec2-user@<instance-ip>:~/

# Navigate to project
cd Conversational-Document-Assistant

# Create .env file for backend
cd backend

# Get your IP first
INSTANCE_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
echo "Your instance IP is: $INSTANCE_IP"

# Create .env file (replace YOUR_OPENAI_KEY with your actual key)
cat > .env << EOF
LLM_PROVIDER=openai
OPENAI_API_KEY=YOUR_OPENAI_KEY_HERE
CORS_ORIGINS=http://${INSTANCE_IP}:80,http://${INSTANCE_IP}
JWT_SECRET=$(openssl rand -hex 32)
DATABASE_URL=sqlite:///./rag.db
DATA_DIR=./data
EOF

# Edit the .env file to add your OpenAI key
nano .env
# Press Ctrl+X, then Y, then Enter to save

# Go back to project root
cd ..

# Start the application
docker-compose up -d

# Check if containers are running
docker ps

# View logs if needed
docker-compose logs -f
```

### Step 6: Verify It's Working

```bash
# Check backend health
curl http://localhost:8000/health

# Check if containers are running
docker ps

# View logs
docker-compose logs backend
docker-compose logs frontend
```

### Step 7: Access Your Application

1. Get your instance public IP from AWS Console (or use the command from Step 4)
2. Open browser: `http://<your-instance-ip>`
3. You should see the frontend!

### Step 8: Set Up Nginx (Optional but Recommended)

If you want to use port 80 directly without specifying ports:

```bash
# Install Nginx
sudo yum install nginx -y  # Amazon Linux
# OR
sudo apt install nginx -y  # Ubuntu

# Create config
sudo nano /etc/nginx/conf.d/rag.conf
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_buffering off;
    }
}
```

```bash
# Test and start Nginx
sudo nginx -t
sudo systemctl start nginx
sudo systemctl enable nginx
```

## 🔧 Troubleshooting

### Docker permission denied
```bash
# Make sure you logged out and back in after adding user to docker group
exit
# SSH back in
```

### Containers not starting
```bash
# Check logs
docker-compose logs

# Check if ports are available
sudo netstat -tulpn | grep -E ':(80|8000)'
```

### Can't access from browser
- Check security group allows HTTP (port 80) from 0.0.0.0/0
- Check if containers are running: `docker ps`
- Check backend logs: `docker-compose logs backend`

### CORS errors
- Make sure CORS_ORIGINS in .env includes your instance IP
- Restart containers: `docker-compose restart`

## 📝 Quick Commands Reference

```bash
# Start application
docker-compose up -d

# Stop application
docker-compose down

# View logs
docker-compose logs -f

# Restart
docker-compose restart

# Check status
docker ps
docker-compose ps
```

## ✅ Final Checklist

- [ ] Docker installed and running
- [ ] Docker Compose installed
- [ ] Repository cloned/uploaded
- [ ] .env file created with correct values
- [ ] Containers running (`docker ps` shows both containers)
- [ ] Can access frontend at `http://<your-ip>`
- [ ] Backend health check works: `curl http://localhost:8000/health`

---

**Need help?** Check the full guide in [AWS_DEPLOYMENT.md](AWS_DEPLOYMENT.md)


