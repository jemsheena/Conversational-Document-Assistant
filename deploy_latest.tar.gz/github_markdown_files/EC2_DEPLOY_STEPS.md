# 🚀 EC2 Deployment Steps

Run these commands **on your EC2 instance** (after SSH connection).

## Step 1: Install Docker and Dependencies

```bash
# Update system
sudo yum update -y

# Install Docker and Git
sudo yum install docker git -y

# Start Docker
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker ec2-user

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installations
docker --version
docker-compose --version
git --version
```

**IMPORTANT:** After running these, log out and SSH back in:
```bash
exit
# Then reconnect: ssh -i fastapi-key.pem ec2-user@52.63.193.17
```

## Step 2: Get Your Instance IP

```bash
# Get your public IP (you'll need this for CORS)
curl http://169.254.169.254/latest/meta-data/public-ipv4
# Should show: 52.63.193.17
```

## Step 3: Clone Your Repository

```bash
# Clone the repository
git clone https://github.com/your-username/Conversational-Document-Assistant.git
# OR if you need to upload from local, see Step 3b below

cd Conversational-Document-Assistant
```

**OR Step 3b: Upload from Your Local Machine**

If your code isn't on GitHub, upload it from your Windows machine:

**In PowerShell (on your local machine):**
```powershell
cd C:\Users\USER\Downloads\Conversational-Document-Assistant
scp -i C:\Users\USER\Downloads\fastapi-key.pem -r . ec2-user@52.63.193.17:~/Conversational-Document-Assistant
```

Then on EC2:
```bash
cd ~/Conversational-Document-Assistant
```

## Step 4: Create .env File

```bash
cd backend

# Get instance IP
INSTANCE_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Create .env file
cat > .env << EOF
LLM_PROVIDER=openai
OPENAI_API_KEY=YOUR_OPENAI_API_KEY_HERE
CORS_ORIGINS=http://${INSTANCE_IP}:80,http://${INSTANCE_IP}
JWT_SECRET=$(openssl rand -hex 32)
DATABASE_URL=sqlite:///./rag.db
DATA_DIR=./data
EOF

# Edit to add your OpenAI API key
nano .env
# Press 'i' to enter insert mode
# Replace YOUR_OPENAI_API_KEY_HERE with your actual OpenAI API key
# Press Esc, then type :wq and press Enter to save and exit
```

## Step 5: Deploy with Docker Compose

```bash
# Go back to project root
cd ..

# Start the application
docker-compose up -d

# Check if containers are running
docker ps

# View logs
docker-compose logs -f
# Press Ctrl+C to exit logs view
```

## Step 6: Verify It's Working

```bash
# Check backend health
curl http://localhost:8000/health

# Should return: {"status":"healthy","service":"rag-api"}
```

## Step 7: Access Your Application

1. Open your browser
2. Go to: `http://52.63.193.17`
3. You should see the frontend!

## Step 8: Set Up Auto-Start (Optional)

```bash
# Create systemd service
sudo nano /etc/systemd/system/rag-assistant.service
```

Add this content:
```ini
[Unit]
Description=RAG Assistant Docker Compose
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/home/ec2-user/Conversational-Document-Assistant
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
User=ec2-user

[Install]
WantedBy=multi-user.target
```

Save and enable:
```bash
sudo systemctl enable rag-assistant.service
sudo systemctl start rag-assistant.service
```

## Troubleshooting

### Can't access from browser
- Check security group allows HTTP (port 80) from 0.0.0.0/0
- Verify containers are running: `docker ps`
- Check logs: `docker-compose logs`

### CORS errors
- Make sure CORS_ORIGINS in .env includes `http://52.63.193.17`
- Restart containers: `docker-compose restart`

### Containers not starting
```bash
# Check logs
docker-compose logs backend
docker-compose logs frontend

# Restart
docker-compose down
docker-compose up -d
```


