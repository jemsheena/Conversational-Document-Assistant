# Fix Missing Files on EC2

Run these commands **on your EC2 instance**:

## Step 1: Check what's missing

```bash
# You're already in the right directory
pwd
# Should show: /home/ec2-user/Conversational-Document-Assistant

# Check if frontend exists
ls -la frontend/

# Check if docker-compose.yml exists
ls -la docker-compose.yml
```

## Step 2: Upload missing files from your local machine

**On your local Windows machine (PowerShell):**

```powershell
cd C:\Users\USER\Downloads\Conversational-Document-Assistant

# Upload docker-compose.yml
scp -i C:\Users\USER\Downloads\fastapi-key.pem docker-compose.yml ec2-user@52.63.193.17:~/Conversational-Document-Assistant/

# Upload frontend directory
scp -i C:\Users\USER\Downloads\fastapi-key.pem -r frontend ec2-user@52.63.193.17:~/Conversational-Document-Assistant/
```

## Step 3: Back on EC2, verify files are there

```bash
# Check docker-compose.yml
ls -la docker-compose.yml

# Check frontend directory
ls -la frontend/

# Should see: src/, package.json, Dockerfile, etc.
```

## Step 4: Update CORS in docker-compose.yml

```bash
# Edit docker-compose.yml to update CORS_ORIGINS
nano docker-compose.yml
```

Find the line:
```
- CORS_ORIGINS=http://localhost:5173,http://localhost:80,http://localhost:3000
```

Change it to:
```
- CORS_ORIGINS=http://52.63.193.17:80,http://52.63.193.17
```

Save: Ctrl+X, Y, Enter

## Step 5: Now start Docker Compose

```bash
docker-compose up -d
docker ps
```


