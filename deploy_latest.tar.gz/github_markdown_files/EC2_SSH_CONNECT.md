# 🔌 How to Connect to EC2 Instance

## You're Currently On: Your Local Windows Machine ❌
## You Need To Be On: Your EC2 Instance (Linux) ✅

## Step 1: Connect to EC2 via SSH

### Option A: Using PowerShell (Windows)

1. **Navigate to where your .pem key file is:**
   ```powershell
   cd C:\Users\USER\Downloads
   # Or wherever you saved your .pem file
   ```

2. **Set permissions on the key file:**
   ```powershell
   icacls.exe your-key-name.pem /inheritance:r
   icacls.exe your-key-name.pem /grant:r "%username%:R"
   ```

3. **Connect via SSH:**
   ```powershell
   ssh -i your-key-name.pem ec2-user@<YOUR-EC2-PUBLIC-IP>
   ```
   
   Replace:
   - `your-key-name.pem` with your actual key file name
   - `<YOUR-EC2-PUBLIC-IP>` with your EC2 instance's public IP address
   
   You can find your EC2 public IP in the AWS Console → EC2 → Instances

### Option B: Using Windows Terminal or WSL

If you have WSL (Windows Subsystem for Linux) installed:
```bash
# In WSL terminal
chmod 400 /mnt/c/Users/USER/Downloads/your-key-name.pem
ssh -i /mnt/c/Users/USER/Downloads/your-key-name.pem ec2-user@<YOUR-EC2-PUBLIC-IP>
```

### Option C: Using PuTTY (Alternative)

1. Download PuTTY: https://www.putty.org/
2. Convert .pem to .ppk using PuTTYgen
3. Connect using PuTTY with the .ppk file

## Step 2: Verify You're Connected

Once connected, you should see something like:
```
       __|  __|_  )
       _|  (     /   Amazon Linux 2023
      ___|\___|___|

https://aws.amazon.com/amazon-linux-2023/
[ec2-user@ip-xxx-xxx-xxx-xxx ~]$
```

**Notice:** The prompt should show `ec2-user@ip-xxx` - this means you're ON the EC2 instance!

## Step 3: Now Run the Commands

**ONCE YOU'RE CONNECTED TO EC2**, run these commands:

```bash
# Check OS (should show Amazon Linux or Ubuntu)
cat /etc/os-release

# Update system
sudo yum update -y  # For Amazon Linux
# OR
sudo apt update && sudo apt upgrade -y  # For Ubuntu

# Install Docker
sudo yum install docker git -y  # Amazon Linux
# OR
sudo apt install docker.io git -y  # Ubuntu

# Start Docker
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker ec2-user

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify
docker --version
docker-compose --version
```

## Quick Reference

**On Your Local Windows Machine:**
- ❌ Don't run Linux commands here
- ✅ Use this to SSH into EC2

**On EC2 Instance (after SSH):**
- ✅ Run all the Linux commands here
- ✅ This is where Docker and your app will run

## Finding Your EC2 IP Address

1. Go to AWS Console: https://console.aws.amazon.com/ec2/
2. Click "Instances" in the left menu
3. Find your instance
4. Copy the "Public IPv4 address" (looks like: 54.123.45.67)

## Troubleshooting SSH Connection

### "Permission denied (publickey)"
- Make sure you're using the correct .pem file
- Check file permissions (use icacls on Windows)
- Verify you're using `ec2-user` (Amazon Linux) or `ubuntu` (Ubuntu)

### "Connection timed out"
- Check security group allows SSH (port 22) from your IP
- Verify the instance is running
- Check the public IP is correct

### "Host key verification failed"
```powershell
# Remove old host key
ssh-keygen -R <YOUR-EC2-IP>
```


