from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException
from jose import jwt
from pydantic import BaseModel

from app.config import settings

router = APIRouter()


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    token: str
    refresh: str


@router.post("/login", response_model=TokenResponse)
async def login(req: LoginRequest):
    # TODO: Validate credentials against database
    # For MVP, accept any email/password
    payload = {
        "sub": req.email,
        "role": "user",
        "exp": datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    }
    refresh_payload = {
        "sub": req.email,
        "exp": datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    }
    token = jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    refresh = jwt.encode(refresh_payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    return TokenResponse(token=token, refresh=refresh)


class RefreshRequest(BaseModel):
    token: str


@router.post("/refresh")
async def refresh(req: RefreshRequest):
    try:
        payload = jwt.decode(req.token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        new_payload = {
            "sub": payload["sub"],
            "role": payload.get("role", "user"),
            "exp": datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
        }
        return {
            "token": jwt.encode(new_payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
