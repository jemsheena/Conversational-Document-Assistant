from collections.abc import Generator

from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.models import Base

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_database() -> list[str]:
    """Create tables if they do not exist. Returns list of table names."""
    inspector = inspect(engine)
    if not inspector.has_table("collections"):
        Base.metadata.create_all(bind=engine)
    inspector = inspect(engine)
    return inspector.get_table_names()
