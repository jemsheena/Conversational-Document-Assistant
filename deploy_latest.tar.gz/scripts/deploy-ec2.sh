#!/usr/bin/env bash
set -euo pipefail

IMAGE_TAG="${1:-latest}"
REGISTRY="${REGISTRY:-ghcr.io}"
REPO_OWNER="${REPO_OWNER:?REPO_OWNER is required (GitHub username or org)}"
APP_DIR="${APP_DIR:-$HOME/Conversational-Document-Assistant}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"

mkdir -p "$APP_DIR/backend/data" "$APP_DIR/scripts"
cd "$APP_DIR"

if [ ! -f "$COMPOSE_FILE" ]; then
  echo "ERROR: $COMPOSE_FILE not found in $APP_DIR"
  exit 1
fi

export BACKEND_IMAGE="${REGISTRY}/${REPO_OWNER}/conversational-document-assistant-backend:${IMAGE_TAG}"
export FRONTEND_IMAGE="${REGISTRY}/${REPO_OWNER}/conversational-document-assistant-frontend:${IMAGE_TAG}"

echo "Deploying backend:  $BACKEND_IMAGE"
echo "Deploying frontend: $FRONTEND_IMAGE"

# Log in on the server only — store GHCR_TOKEN in EC2 .env, not in GitHub.
if [ -f .env ] && grep -q '^GHCR_TOKEN=' .env 2>/dev/null; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi
if [ -n "${GHCR_TOKEN:-}" ]; then
  echo "$GHCR_TOKEN" | docker login ghcr.io -u "$REPO_OWNER" --password-stdin
fi

docker compose -f "$COMPOSE_FILE" pull
docker compose -f "$COMPOSE_FILE" up -d
docker compose -f "$COMPOSE_FILE" ps
