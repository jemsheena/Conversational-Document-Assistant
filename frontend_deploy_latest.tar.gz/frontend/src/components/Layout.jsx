import { Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../store/useAuth.jsx'
import { Plus, MessageSquare, LogOut, Pencil, Pin, PinOff, Eraser } from 'lucide-react'
import { useState, useEffect, useCallback } from 'react'

export default function Layout({
  children,
  conversations,
  activeConv,
  onNewChat,
  onSelectConv,
  onRenameConv,
  onTogglePinConv,
  onClearConv,
}) {
  const { logout } = useAuth()
  const navigate = useNavigate()

  const sortedConversations = [...conversations].sort((a, b) => {
    if (a.pinned === b.pinned) return 0
    return a.pinned ? -1 : 1
  })

  const handleLogout = () => {
    logout()
    navigate('/auth')
  }

  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <button className="new-chat-btn" onClick={onNewChat}>
            <Plus size={18} />
            <span>New chat</span>
          </button>
        </div>

        <div className="sidebar-conversations">
          {sortedConversations.map((conv) => (
            <div
              key={conv.id}
              className={`conv-item ${activeConv === conv.id ? 'active' : ''}`}
              onClick={() => onSelectConv(conv.id)}
            >
              <MessageSquare size={16} />
              <span className="conv-title">{conv.title || 'New conversation'}</span>
              <div className="conv-actions">
                <button
                  className="conv-action-btn"
                  title={conv.pinned ? 'Unpin conversation' : 'Pin conversation'}
                  onClick={(e) => {
                    e.stopPropagation()
                    onTogglePinConv?.(conv.id)
                  }}
                >
                  {conv.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                </button>
                <button
                  className="conv-action-btn"
                  title="Rename conversation"
                  onClick={(e) => {
                    e.stopPropagation()
                    const nextName = window.prompt('Rename conversation', conv.title || '')
                    if (nextName !== null) {
                      onRenameConv?.(conv.id, nextName)
                    }
                  }}
                >
                  <Pencil size={13} />
                </button>
                <button
                  className="conv-action-btn"
                  title="Clear conversation"
                  onClick={(e) => {
                    e.stopPropagation()
                    onClearConv?.(conv.id)
                  }}
                >
                  <Eraser size={13} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="sidebar-footer">
          <div className="sidebar-user" onClick={handleLogout}>
            <div className="user-avatar">U</div>
            <span>Log out</span>
            <LogOut size={16} style={{ marginLeft: 'auto' }} />
          </div>
        </div>
      </aside>

      {/* Chat Area */}
      <div className="chat-area">
        {children}
      </div>
    </div>
  )
}
