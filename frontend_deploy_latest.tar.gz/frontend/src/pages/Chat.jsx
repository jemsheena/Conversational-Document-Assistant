import { useState, useRef, useEffect, useCallback } from 'react'
import Message from '../components/Message'
import { Send, Paperclip, FileText, Upload, X, Sparkles } from 'lucide-react'
import { listCollections } from '../api/client'

export default function Chat({ chat }) {
  const {
    messages, currentResponse, isLoading, isUploading,
    activeConversation, setActiveCollection, sendMessage, uploadFiles
  } = chat

  const [input, setInput] = useState('')
  const [showUpload, setShowUpload] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [selectedFiles, setSelectedFiles] = useState([])
  const [showSources, setShowSources] = useState(false)
  const [sources, setSources] = useState([])
  const [collections, setCollections] = useState([])
  const [showUploadSuccess, setShowUploadSuccess] = useState(false)
  const messagesEndRef = useRef(null)
  const fileInputRef = useRef(null)
  const textareaRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, currentResponse])

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px'
    }
  }, [input])

  useEffect(() => {
    const loadCollections = async () => {
      try {
        const data = await listCollections()
        setCollections(data)
      } catch (error) {
        console.error('Failed to load collections:', error)
      }
    }
    loadCollections()
  }, [])

  useEffect(() => {
    if (!activeConversation?.lastUpload?.at) return
    setShowUploadSuccess(true)
    const timer = setTimeout(() => setShowUploadSuccess(false), 4000)
    return () => clearTimeout(timer)
  }, [activeConversation?.lastUpload?.at, activeConversation?.id])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return
    const query = input
    setInput('')
    await sendMessage(query)
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    setDragActive(false)
    const files = Array.from(e.dataTransfer.files).filter(f => f.name.endsWith('.pdf'))
    if (files.length > 0) {
      setSelectedFiles(files)
      setShowUpload(true)
    }
  }, [])

  const handleDragOver = useCallback((e) => {
    e.preventDefault()
    setDragActive(true)
  }, [])

  const handleDragLeave = useCallback((e) => {
    e.preventDefault()
    setDragActive(false)
  }, [])

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files).filter(f => f.name.endsWith('.pdf'))
    if (files.length > 0) {
      setSelectedFiles(prev => [...prev, ...files])
      setShowUpload(true)
    }
  }

  const handleUpload = async () => {
    if (selectedFiles.length === 0) return
    try {
      await uploadFiles(selectedFiles)
      setSelectedFiles([])
      setShowUpload(false)
    } catch (err) {
      alert('Upload failed: ' + (err.message || 'Unknown error'))
    }
  }

  const handleShowSources = (src) => {
    setSources(src)
    setShowSources(true)
  }

  const renderCollectionSelector = () => (
    <div style={{ marginBottom: 8, display: 'flex', justifyContent: 'flex-end' }}>
      <select
        value={activeConversation?.collection || 'default'}
        onChange={(e) => setActiveCollection(e.target.value)}
        style={{
          padding: '6px 10px',
          borderRadius: 8,
          border: '1px solid var(--border)',
          background: 'var(--bg-secondary)',
          color: 'var(--text-primary)',
          fontSize: 12,
          maxWidth: 220,
        }}
      >
        <option value="default">default</option>
        {collections.map((collection) => (
          <option key={collection.id} value={collection.id}>
            {collection.name}
          </option>
        ))}
      </select>
    </div>
  )

  // Welcome screen when no messages
  if (messages.length === 0 && !currentResponse) {
    return (
      <>
        <div
          className="welcome-screen"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          {dragActive && (
            <div className="upload-overlay" style={{ position: 'absolute', inset: 0 }}>
              <div className="upload-card">
                <Upload size={48} style={{ color: 'var(--accent)', margin: '0 auto 16px' }} />
                <h3>Drop your PDFs here</h3>
              </div>
            </div>
          )}

          <div className="welcome-logo">
            <Sparkles size={28} color="white" />
          </div>
          <h1 className="welcome-title">Document Assistant</h1>
          <p className="welcome-subtitle">
            Upload PDFs and ask questions about your documents
          </p>

          <div className="welcome-cards">
            <div className="welcome-card" onClick={() => setShowUpload(true)}>
              📄 Upload a PDF to get started
            </div>
            <div className="welcome-card" onClick={() => setInput('Summarize the key points')}>
              ✨ "Summarize the key points"
            </div>
            <div className="welcome-card" onClick={() => setInput('What is the main topic?')}>
              💡 "What is the main topic?"
            </div>
            <div className="welcome-card" onClick={() => setInput('Explain in simple terms')}>
              🔍 "Explain in simple terms"
            </div>
          </div>
        </div>

        {/* Input bar on welcome screen */}
        <div className="input-area">
          <div className="input-container">
            {renderCollectionSelector()}
            <div className="chat-input-wrapper">
              <button
                className="input-btn"
                onClick={() => { setShowUpload(true) }}
                title="Upload PDF"
              >
                <Paperclip size={20} />
              </button>
              <textarea
                ref={textareaRef}
                className="chat-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Upload a PDF first, then ask a question..."
                rows={1}
              />
              <div className="input-actions">
                <button
                  className="input-btn send"
                  disabled={!input.trim() || isLoading}
                  onClick={handleSubmit}
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Upload Modal */}
        {showUpload && (
          <UploadModal
            files={selectedFiles}
            setFiles={setSelectedFiles}
            onUpload={handleUpload}
            onClose={() => { setShowUpload(false); setSelectedFiles([]) }}
            isUploading={isUploading}
            fileInputRef={fileInputRef}
          />
        )}
      </>
    )
  }

  // Chat view with messages
  return (
    <>
      {showUploadSuccess && activeConversation?.lastUpload && (
        <div className="processing-banner" style={{ background: '#ecfdf3', color: '#166534' }}>
          Uploaded {activeConversation.lastUpload.count} file
          {activeConversation.lastUpload.count !== 1 ? 's' : ''} successfully
          {activeConversation.lastUpload.indexed > 0
            ? ` (${activeConversation.lastUpload.indexed} chunks indexed)`
            : ''}
        </div>
      )}

      {isUploading && (
        <div className="processing-banner">
          <div className="typing-indicator"><span></span><span></span><span></span></div>
          Processing documents...
        </div>
      )}

      <div className="chat-messages" onDrop={handleDrop} onDragOver={handleDragOver} onDragLeave={handleDragLeave}>
        {messages.map((msg, idx) => (
          <Message
            key={idx}
            message={msg}
            onShowSources={handleShowSources}
          />
        ))}

        {currentResponse && (
          <Message
            message={{ role: 'assistant', content: currentResponse }}
            isStreaming
          />
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="input-area">
        <div className="input-container">
          {renderCollectionSelector()}
          <div className="chat-input-wrapper">
            <button
              className="input-btn"
              onClick={() => setShowUpload(true)}
              title="Upload PDF"
            >
              <Paperclip size={20} />
            </button>
            <textarea
              ref={textareaRef}
              className="chat-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about your documents..."
              rows={1}
            />
            <div className="input-actions">
              <button
                className="input-btn send"
                disabled={!input.trim() || isLoading}
                onClick={handleSubmit}
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Upload Modal */}
      {showUpload && (
        <UploadModal
          files={selectedFiles}
          setFiles={setSelectedFiles}
          onUpload={handleUpload}
          onClose={() => { setShowUpload(false); setSelectedFiles([]) }}
          isUploading={isUploading}
          fileInputRef={fileInputRef}
        />
      )}

      {/* Sources Panel */}
      {showSources && (
        <div className="upload-overlay" onClick={() => setShowSources(false)}>
          <div className="upload-card" onClick={(e) => e.stopPropagation()} style={{ maxHeight: '70vh', overflow: 'auto', textAlign: 'left' }}>
            <h3 style={{ marginBottom: 16 }}>Sources</h3>
            {sources.map((src, i) => (
              <div key={i} className="upload-file-item" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 4 }}>
                <strong style={{ color: 'var(--text-primary)', fontSize: 13 }}>
                  {src.doc} — Page {src.page}
                </strong>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.4 }}>
                  {src.snippet}
                </p>
              </div>
            ))}
            <button className="upload-cancel" onClick={() => setShowSources(false)}>Close</button>
          </div>
        </div>
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept=".pdf"
        multiple
        hidden
      />
    </>
  )
}

function UploadModal({ files, setFiles, onUpload, onClose, isUploading, fileInputRef }) {
  const [dragActive, setDragActive] = useState(false)

  const handleDrop = (e) => {
    e.preventDefault()
    setDragActive(false)
    const newFiles = Array.from(e.dataTransfer.files).filter(f => f.name.endsWith('.pdf'))
    setFiles(prev => [...prev, ...newFiles])
  }

  return (
    <div className="upload-overlay" onClick={onClose}>
      <div className="upload-card" onClick={(e) => e.stopPropagation()}>
        <h3 style={{ fontSize: 18, marginBottom: 4 }}>Upload Documents</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Add PDF files to chat with</p>

        <div
          className={`upload-dropzone ${dragActive ? 'active' : ''}`}
          onDrop={handleDrop}
          onDragOver={(e) => { e.preventDefault(); setDragActive(true) }}
          onDragLeave={() => setDragActive(false)}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload size={32} style={{ color: 'var(--text-muted)', margin: '0 auto' }} />
          <p>Drag & drop PDFs here or click to browse</p>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={(e) => {
            const newFiles = Array.from(e.target.files).filter(f => f.name.endsWith('.pdf'))
            setFiles(prev => [...prev, ...newFiles])
          }}
          accept=".pdf"
          multiple
          hidden
        />

        {files.length > 0 && (
          <ul className="upload-file-list">
            {files.map((f, i) => (
              <li key={i} className="upload-file-item">
                <FileText size={16} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.name}</span>
                <button
                  onClick={() => setFiles(prev => prev.filter((_, j) => j !== i))}
                  style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                >
                  <X size={14} />
                </button>
              </li>
            ))}
          </ul>
        )}

        <button
          className="upload-btn"
          onClick={onUpload}
          disabled={files.length === 0 || isUploading}
        >
          {isUploading ? 'Processing...' : `Upload ${files.length} file${files.length !== 1 ? 's' : ''}`}
        </button>
        <br />
        <button className="upload-cancel" onClick={onClose}>Cancel</button>
      </div>
    </div>
  )
}
