import { useEffect, useState } from 'react'
import { chatStream, ingestDocuments } from '../api/client'

const DEFAULT_COLLECTION = 'default'
const NEW_CONV_TITLE = 'New conversation'
const STORAGE_KEY = 'chat_state_v1'

function createConversation() {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: NEW_CONV_TITLE,
    pinned: false,
    collection: DEFAULT_COLLECTION,
    messages: [],
    hasDocuments: false,
    lastUpload: null,
  }
}

function normalizeConversation(conv) {
  return {
    id: conv?.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: conv?.title || NEW_CONV_TITLE,
    pinned: Boolean(conv?.pinned),
    collection: conv?.collection || DEFAULT_COLLECTION,
    messages: Array.isArray(conv?.messages) ? conv.messages : [],
    hasDocuments: Boolean(conv?.hasDocuments),
    lastUpload: conv?.lastUpload || null,
  }
}

function loadInitialState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) {
      const initial = createConversation()
      return { conversations: [initial], activeConvId: initial.id }
    }

    const parsed = JSON.parse(raw)
    const loadedConversations = Array.isArray(parsed?.conversations)
      ? parsed.conversations.map(normalizeConversation)
      : []
    const conversations = loadedConversations.length > 0 ? loadedConversations : [createConversation()]
    const activeConvId =
      conversations.find((conv) => conv.id === parsed?.activeConvId)?.id ?? conversations[0].id
    return { conversations, activeConvId }
  } catch {
    const initial = createConversation()
    return { conversations: [initial], activeConvId: initial.id }
  }
}

export function useChat() {
  const [initialState] = useState(loadInitialState)
  const [conversations, setConversations] = useState(initialState.conversations)
  const [activeConvId, setActiveConvId] = useState(initialState.activeConvId)
  const [isLoading, setIsLoading] = useState(false)
  const [currentResponse, setCurrentResponse] = useState('')
  const [isUploading, setIsUploading] = useState(false)

  const activeConversation = conversations.find((conv) => conv.id === activeConvId) ?? null
  const messages = activeConversation?.messages ?? []

  const updateActiveConversation = (updater) => {
    setConversations((prev) =>
      prev.map((conv) => (conv.id === activeConvId ? updater(conv) : conv))
    )
  }

  const createNewChat = () => {
    const next = createConversation()
    setConversations((prev) => [next, ...prev])
    setActiveConvId(next.id)
    setCurrentResponse('')
    return next.id
  }

  const selectConversation = (id) => {
    setActiveConvId(id)
    setCurrentResponse('')
  }

  const setActiveCollection = (collection) => {
    updateActiveConversation((conv) => ({ ...conv, collection: collection || DEFAULT_COLLECTION }))
  }

  const renameConversation = (id, title) => {
    const nextTitle = title?.trim()
    if (!nextTitle) return
    setConversations((prev) =>
      prev.map((conv) => (conv.id === id ? { ...conv, title: nextTitle } : conv))
    )
  }

  const togglePinConversation = (id) => {
    setConversations((prev) =>
      prev.map((conv) => (conv.id === id ? { ...conv, pinned: !conv.pinned } : conv))
    )
  }

  const clearConversationMessages = (id) => {
    setConversations((prev) =>
      prev.map((conv) =>
        conv.id === id
          ? { ...conv, messages: [], lastUpload: null, hasDocuments: false }
          : conv
      )
    )
    if (id === activeConvId) {
      setCurrentResponse('')
    }
  }

  useEffect(() => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        conversations,
        activeConvId,
      })
    )
  }, [conversations, activeConvId])

  const sendMessage = async (query, options = {}) => {
    let targetConvId = activeConvId
    if (!targetConvId) {
      targetConvId = createNewChat()
    }
    const targetConversation = conversations.find((conv) => conv.id === targetConvId)
    const targetCollection = targetConversation?.collection || DEFAULT_COLLECTION

    // Add user message
    const userMessage = { role: 'user', content: query }
    setConversations((prev) =>
      prev.map((conv) => {
        if (conv.id !== targetConvId) return conv
        const nextTitle =
          conv.title === NEW_CONV_TITLE
            ? query.slice(0, 40) || NEW_CONV_TITLE
            : conv.title
        return { ...conv, title: nextTitle, messages: [...conv.messages, userMessage] }
      })
    )
    setIsLoading(true)
    setCurrentResponse('')

    let fullResponse = ''

    try {
      await chatStream(
        targetCollection,
        query,
        options,
        (token) => {
          fullResponse += token
          setCurrentResponse(fullResponse)
        },
        (sources) => {
          setConversations((prev) =>
            prev.map((conv) => {
              if (conv.id !== targetConvId) return conv
              return {
                ...conv,
                messages: [
                  ...conv.messages,
                  {
                    role: 'assistant',
                    content: fullResponse,
                    sources,
                  },
                ],
              }
            })
          )
          setCurrentResponse('')
        },
        (error) => {
          console.error('Chat error:', error)
          setConversations((prev) =>
            prev.map((conv) =>
              conv.id === targetConvId
                ? {
                    ...conv,
                    messages: [
                      ...conv.messages,
                      { role: 'assistant', content: `Error: ${error}` },
                    ],
                  }
                : conv
            )
          )
          setCurrentResponse('')
        }
      )
    } catch (error) {
      console.error('Chat error:', error)
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetConvId
            ? {
                ...conv,
                messages: [
                  ...conv.messages,
                  { role: 'assistant', content: `Error: ${error.message}` },
                ],
              }
            : conv
        )
      )
      setCurrentResponse('')
    } finally {
      setIsLoading(false)
    }
  }

  const uploadFiles = async (files) => {
    let targetConvId = activeConvId
    if (!targetConvId) {
      targetConvId = createNewChat()
    }
    const targetConversation = conversations.find((conv) => conv.id === targetConvId)
    const targetCollection = targetConversation?.collection || DEFAULT_COLLECTION

    setIsUploading(true)
    try {
      const result = await ingestDocuments(targetCollection, files)
      const uploadCount = Array.isArray(files) ? files.length : 0
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetConvId
            ? {
                ...conv,
                hasDocuments: true,
                lastUpload: {
                  count: uploadCount,
                  indexed: result?.indexed ?? 0,
                  at: new Date().toISOString(),
                },
              }
            : conv
        )
      )
      return result
    } catch (error) {
      console.error('Upload error:', error)
      throw error
    } finally {
      setIsUploading(false)
    }
  }

  const clearActiveMessages = () => {
    updateActiveConversation((conv) => ({ ...conv, messages: [] }))
    setCurrentResponse('')
  }

  return {
    conversations,
    activeConvId,
    activeConversation,
    messages,
    currentResponse,
    isLoading,
    isUploading,
    createNewChat,
    selectConversation,
    setActiveCollection,
    renameConversation,
    togglePinConversation,
    clearConversationMessages,
    sendMessage,
    uploadFiles,
    clearActiveMessages,
  }
}
